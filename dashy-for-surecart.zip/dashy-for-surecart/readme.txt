=== dashy for surecart ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: dashboard, tabs, surecart, custom icons, shortcode
Requires at least: 
Tested up to: 
Stable tag: 
Requires PHP: 
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Easily add Dashboard Tabs to SureCart with Dashy – a plugin that allows you to add custom dashboard tabs with dynamic content,
custom icons, and the flexibility to load content via Page/Post, Custom Post Type, or shortcode.

== Installation ==
1. Upload the `dashy-for-surecart` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings under the Dashboard Tabs menu in your WordPress admin area.

== Frequently Asked Questions ==
= How do I add a new dashboard tab? =
After activating the plugin, navigate to the Dashboard Tabs settings and click "Add New" to create a new tab.
= Can I customize the tab icons? =
Yes, you can upload custom icons directly via the plugin settings.
== Changelog ==
=1.22 ( 24 March 2025) =
Tweaked: Layout
Fixed: Some reports of non loading menu
Tweaked: Update Location Changed

= 1.21 (20 March 2025) =
Tweaked: Updater Settings

= 1.2 (18 March 2025) =
Tweaked: Admin Settings
Fixed: Spelling Issue

= 1.12 (03 March 2025) =
Tweaked: Moved Dashboard Tabs Manager menu to Settings > SC Dashboard Tabs.
Fixed: Resolved issue with the "Select Image" button not functioning.

= 1.11 (28 February 2025) =
New: Added dynamic post type selector allowing users to choose from all registered public post types.
Improvement: Enhanced content source field behavior so that the Post Type column remains in place (even when hidden) to avoid layout shifts.
Tweaked: Updated UI to better distinguish between “page” and “shortcode/code” content types.

= 1.1 (20 February 2025) =
New: Integrated dynamic icon styling support by automatically assigning an icon name based on the uploaded icon URL.
Fixed: Minor admin settings page bugs and improved media uploader functionality.

= 1.01 (15 February 2025) =
Tweaked: Refined admin interface for managing dashboard tabs.
Improvement: Added option to hide the Post Type column when content type isn’t “page” to reduce user confusion.

= 1.0 (10 February 2025) =
New: Initial release of Surecart Dashboard Tabs Manager with full functionality for adding, editing, and removing custom dashboard tabs.
New: Supported dynamic icon styling with media uploader integration.
New: Provided dynamic content sourcing via page/post selection, shortcode processing, and PHP code execution.