=== Dashy For SureCart ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: surecart, dashboard, tabs, ecommerce
Requires at least: 6.5
Tested up to: 7.0
Stable tag: 1.30.0
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Easily add Dashboard Tabs to SureCart with Dashy – a plugin that allows you to add custom dashboard tabs with dynamic content,
custom icons, and the flexibility to load content via Page/Post, Custom Post Type, or shortcode.

== Description ==

Easily add Dashboard Tabs to SureCart with Dashy – a plugin that allows you to add custom dashboard tabs with dynamic content,
custom icons, and the flexibility to load content via Page/Post, Custom Post Type, or shortcode.

== Installation ==

1. Upload the `dashy-for-surecart` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings under the Dashboard Tabs menu in your WordPress admin area.

== Frequently Asked Questions ==
= How do I add a new dashboard tab? =
After activating the plugin, navigate to the Dashboard Tabs settings and click "Add New" to create a new tab.
= Can I customize the tab icons? =
Yes, you can upload custom icons directly via the plugin settings.
== Changelog ==
= 1.30.0 25 May 2026 =
New: Beta Support for FSE
Improvement: Pages / Post Type now auto populate
Improvement: Menu Item is now in the Sure Cart Menu
New: Significant fallback for edge cases exist.
Tweaked: Tested Version now 7.0
Tweaked: Native Icon Handling


= 1.29.7 23 March 2026 =
Update: Updater to 2.0-Alpha
Update: Compatibility

= 1.29.6 9 November 2025 =
Fixed: Tab Directory issue

= 1.29.5 5 August 2025 =
New: Deploy Methodology 
New: Production Test - New deploy.sh 
Fixed: Icon Issue

= 1.29.4 5 August 2025 =
Fixed: Comment out WP Icon Filter which is causing issues in latest MainWP

= 1.29.3 2 Aug 2025 =
Fixed: Icon Filer Issue
Fixed: Tabs Missing

= 1.29.2 2 Aug 2025 =
New: MainWP Icon Filter

= 1.29.1 27 July 2025 =
New: Prepare Future Support for Preleases
New: Updated UUPD to 1.3.0

= 1.29 14 July 2025 =
Update: UUPD 1.2.5

= 1.28 06 July 2025 =
New: Rescoped RUP_UUPD
Update: UUPD 1.2.4

= 1.27 ( 21 June 2025) =
New: Updates Now served directly from GitHub using UUPD

= 1.26 ( 21 June 2025) =
Tweaked: Updates Now served directly from GitHub using UUPD

= 1.25 ( 20 May 2025) =
Fixed: Issues with some installations running brick 2.0 Alpha, this will need checking against the final release but should stop issues now

= 1.24 ( 5 May 2025) =
Tweaked: Tested 6.8.1

= 1.23 ( 4 April 2025) =
Fixed: Minor Bug Fix

= 1.22 ( 24 March 2025) =
Tweaked: Layout
Fixed: Some reports of non loading menu
Tweaked: Update Location Changed

= 1.21 (20 March 2025) =
Tweaked: Updater Settings

= 1.2 (18 March 2025) =
Tweaked: Admin Settings
Fixed: Spelling Issue

= 1.12 (03 March 2025) =
Tweaked: Moved Dashboard Tabs Manager menu to Settings > SC Dashboard Tabs.
Fixed: Resolved issue with the "Select Image" button not functioning.

= 1.11 (28 February 2025) =
New: Added dynamic post type selector allowing users to choose from all registered public post types.
Improvement: Enhanced content source field behavior so that the Post Type column remains in place (even when hidden) to avoid layout shifts.
Tweaked: Updated UI to better distinguish between “page” and “shortcode/code” content types.

= 1.1 (20 February 2025) =
New: Integrated dynamic icon styling support by automatically assigning an icon name based on the uploaded icon URL.
Fixed: Minor admin settings page bugs and improved media uploader functionality.

= 1.01 (15 February 2025) =
Tweaked: Refined admin interface for managing dashboard tabs.
Improvement: Added option to hide the Post Type column when content type isn’t “page” to reduce user confusion.

= 1.0 (10 February 2025) =
New: Initial release of Surecart Dashboard Tabs Manager with full functionality for adding, editing, and removing custom dashboard tabs.
New: Supported dynamic icon styling with media uploader integration.
New: Provided dynamic content sourcing via page/post selection, shortcode processing, and PHP code execution.